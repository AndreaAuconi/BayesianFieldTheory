"""
update_K2.py
============

Regenerates the outputs of `stochastic.py` that depend on the K^(2) kernel, after
the correction of the dk' integral.

BACKGROUND
----------
In `compute_integral_K2_montecarlo` the square bracket returned by the Gradshteyn
dk integral is

    [ s_- cos(R3 s_-/tau) + s_+ sin(R3 s_-/tau) ],
    s_pm = sqrt( (sqrt(1+k'^2) +- 1) / 2 ),

and BOTH terms are even in k' (because sqrt(1+k'^2) is), so neither drops out of
the dk' integral. The original implementation kept only the first term. The two
agree on the diagonal t = t' (where the sine argument vanishes) but off-diagonal
the old kernel is too small by 35% up to a factor of 3.

The fix adds  s_+/tan(theta) = sqrt(cos theta) / (2 sin(theta/2))  alongside the
existing  s_-/tan(theta) = sqrt(cos theta) / (2 cos(theta/2)).

WHAT THIS SCRIPT DOES
---------------------
It reuses everything already saved by `stochastic.py`, so the expensive parts --
the MAP relaxation and the SPDE Langevin sampling -- are NOT rerun. Only K^(2)
and the quantities downstream of it are recomputed. The Monte Carlo estimator is
kept identical in form to the one in `stochastic.py`.

INPUTS  (must sit in the working directory, as written by stochastic.py)
    long_optimum.npy   f.npy   J.npy   K1.npy
    t_grid.npy   x_grid.npy   Gauss.npy   numerical.npy
    K2.npy             (optional -- only to print the old-vs-new comparison)

OUTPUTS
    K2_updated.npy
    theory_updated.npy
    NP_Theory_updated.npy
    double_K2_updated.pdf
    double_K_G_ff_updated.pdf
    numerical_path_impact_updated.pdf
    numerical_path_only_updated.pdf

Unchanged by the fix, so NOT regenerated: ML.pdf, J_integral.pdf,
var_J_correction.pdf, var_excess.pdf, double_K1.pdf.
"""

import datetime
import multiprocessing
import os

import numpy as np
import matplotlib.pyplot as plt
from scipy.special import erf
from joblib import Parallel, delayed
from numba import njit
from tqdm import tqdm

print(datetime.datetime.now())

# ----------------------------------------------------------------------------
# configuration
# ----------------------------------------------------------------------------
IN_DIR = "."      # where stochastic.py wrote its .npy files
OUT_DIR = "."     # where the *_updated.* files go
SUFFIX = "_updated"

fraction_cores = 1.0

# ----------------------------------------------------------------------------
# constants -- must match stochastic.py exactly
# ----------------------------------------------------------------------------
sigma = 0.02
n = 351
integration_factor = 2.0
rescale = 200
length_factor = 10.0
n_samples = 80
n_std_grid = 6.0
factor_long = 100

MC_samples = int(5e5 * integration_factor)   # same as stochastic.py

n_ML = n * rescale
corr_length = 1 / sigma
T = corr_length * length_factor
dt = T / n
dt_ML = T / n_ML
t_grid = np.array([dt * i for i in range(n)])
mid_n = int(n / 2)
mid_n_ML = int(n_ML / 2)
t_from_point = t_grid - dt * mid_n
t_pairs = [(t, tp) for t in t_from_point for tp in t_from_point]

dx_grid = 2 * n_std_grid * np.sqrt(sigma / 2) / n_samples
x_grid = np.array([(i + 0.5 - n_samples / 2) * dx_grid for i in range(n_samples)])
dx_grid_long = dx_grid / factor_long
x_grid_long = np.array(
    [(i + 0.5 - factor_long * n_samples / 2) * dx_grid_long
     for i in range(factor_long * n_samples)]
)

n_cores = int(multiprocessing.cpu_count() * fraction_cores)

# ----------------------------------------------------------------------------
# load what stochastic.py already computed
# ----------------------------------------------------------------------------
def load(name):
    path = os.path.join(IN_DIR, name)
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"{path} not found -- run stochastic.py first, or point IN_DIR at its output."
        )
    return np.load(path)

long_optimum = load("long_optimum.npy")
f = load("f.npy")
J = load("J.npy")
K1 = load("K1.npy")
Gauss = load("Gauss.npy")
numerical = load("numerical.npy")

K2_old_path = os.path.join(IN_DIR, "K2.npy")
K2_old = np.load(K2_old_path) if os.path.exists(K2_old_path) else None

# ----------------------------------------------------------------------------
# recover alpha, nu, beta  (identical to stochastic.py: alpha = r_star[mid_n])
# ----------------------------------------------------------------------------
r_star = np.array([np.mean(long_optimum[i * rescale:(i + 1) * rescale]) for i in range(n)])
alpha = r_star[mid_n]
nu = sigma / (2 * np.sqrt(alpha))
sqrt_nu = np.sqrt(nu)
beta = sigma * np.sqrt(alpha)

# cross-checks against the saved arrays
assert np.allclose(f, r_star - alpha, atol=1e-12), "f.npy inconsistent with long_optimum.npy"
nu_from_J = np.sqrt(-J[mid_n])          # J_0 = -nu^2 exactly
print(f"alpha = {alpha:.6f}   nu = {nu:.6e}   tau = {1/beta:.4f}")
print(f"consistency check  sqrt(-J_0)/nu = {nu_from_J/nu:.6f}  (should be 1 up to MC noise)")

# ----------------------------------------------------------------------------
# corrected K^(2) kernel -- same Monte Carlo estimator as stochastic.py
# ----------------------------------------------------------------------------
@njit
def compute_integral_K2_montecarlo(t, t_prime):
    R1 = np.abs(t - t_prime) + np.abs(t) + np.abs(t_prime)
    R2 = np.abs(t) - np.abs(t_prime)
    R3 = np.abs(t - t_prime)
    theta_max = np.pi / 2.0
    theta = np.random.uniform(0.0, theta_max, MC_samples)
    cos_theta = np.cos(theta)
    sec_theta = 1.0 / (cos_theta + 1e-20)
    A_theta = np.sqrt((sec_theta - 1.0) / 2.0)          # s_-
    B_theta = np.sqrt((sec_theta + 1.0) / 2.0)          # s_+
    Exp_arg = -beta * R1 * B_theta
    Cos1_arg = beta * R2 * A_theta
    Cos2_arg = beta * R3 * A_theta
    A_over_tan = (1.0 / (2.0 * np.cos(theta / 2.0))) * np.sqrt(cos_theta)   # s_-/tan(theta)
    B_over_tan = np.sqrt(cos_theta) / (2.0 * np.sin(theta / 2.0) + 1e-20)   # s_+/tan(theta)
    bracket = A_over_tan * np.cos(Cos2_arg) + B_over_tan * np.sin(Cos2_arg)
    g_theta = (1.0 / np.pi) * bracket * np.exp(Exp_arg) * np.cos(Cos1_arg)
    integral_estimate_0_to_inf = (theta_max / MC_samples) * np.sum(g_theta)
    integral_estimate_neg_inf_to_inf = 2.0 * integral_estimate_0_to_inf
    integral_estimate = nu**3 * integral_estimate_neg_inf_to_inf
    return integral_estimate


print("Recomputing K2 with the corrected kernel ...")
pre_K2 = Parallel(n_jobs=n_cores)(
    delayed(compute_integral_K2_montecarlo)(t, tp) for t, tp in tqdm(t_pairs))
K2 = np.array(pre_K2).reshape((n, n))
np.save(os.path.join(OUT_DIR, f"K2{SUFFIX}.npy"), K2)
print(datetime.datetime.now())

# ----------------------------------------------------------------------------
# path integrals  (verbatim from stochastic.py)
# ----------------------------------------------------------------------------
path_integral_J = np.sum(f * J) * dt
double_path_integral_K1 = np.sum(K1 * np.outer(f, f)) * dt**2
double_path_integral_K2 = np.sum(K2 * np.outer(f, f)) * dt**2

G1u = nu * np.exp(-beta * np.abs(t_from_point))

# rolls precomputed once; the windowing logic is identical to stochastic.py
F_roll = np.empty((n, n))
for i in range(n):
    F_roll[i] = np.roll(f, mid_n - i)
gaps = np.abs(mid_n - np.arange(n))

G_f = np.zeros(n)
G_ff = np.zeros((n, n))
for i in range(n):
    gap_i = gaps[i]
    if gap_i > 0:
        G_f[i] = np.sum((G1u * F_roll[i])[gap_i:-gap_i]) * dt
    else:
        G_f[i] = np.sum(G1u * F_roll[i]) * dt
    prod = G1u * F_roll[i] * F_roll                  # (n, n): row j = integrand for (i, j)
    csum = np.concatenate([np.zeros((n, 1)), np.cumsum(prod, axis=1)], axis=1)
    g_row = np.maximum(gap_i, gaps)                  # window = max(gap_i, gap_j)
    G_ff[i] = (csum[np.arange(n), n - g_row] - csum[np.arange(n), g_row]) * dt

spatial_var_correction = -(alpha / 2) * (np.sum(J * G_f) * dt
                                         + np.sum((K1 + K2) * G_ff) * dt**2)

delta_Gf_f = G_f - f / alpha
overline_f0_delta_Gf_f = np.zeros(n)
for i in range(n):
    delta_Gf_f_t_tp = np.roll(delta_Gf_f, mid_n - i)
    gap_i = gaps[i]
    if gap_i > 0:
        overline_f0_delta_Gf_f[i] = np.sum((G1u * f * delta_Gf_f_t_tp)[gap_i:-gap_i]) * dt
    else:
        overline_f0_delta_Gf_f[i] = np.sum(G1u * f * delta_Gf_f_t_tp) * dt

path_var_excess = (alpha / 2) * np.sum(J * overline_f0_delta_Gf_f) * dt
x_correction = spatial_var_correction + path_var_excess
path_delta_nu = path_integral_J + double_path_integral_K1 + double_path_integral_K2

print()
print("--- perturbative corrections, in units of nu^2 ---")
print(f"  J.f                     {path_integral_J/nu**2:+.6f}")
print(f"  K1.ff                   {double_path_integral_K1/nu**2:+.6f}")
print(f"  K2.ff                   {double_path_integral_K2/nu**2:+.6f}")
print(f"  mean, shape part        {spatial_var_correction/nu**2:+.6f}")
print(f"  mean, excess part       {path_var_excess/nu**2:+.6f}")

# ----------------------------------------------------------------------------
# corrected posterior density
# ----------------------------------------------------------------------------
delta_nu = nu**2 / 9 + path_delta_nu
adj_nu = nu + delta_nu
delta_mu = -nu / 2 + x_correction

adj_Gauss = []
for x in x_grid_long:
    up = 0.5 * (1 + erf((x + dx_grid_long / 2 - delta_mu) / np.sqrt(2 * adj_nu)))
    down = 0.5 * (1 + erf((x - dx_grid_long / 2 - delta_mu) / np.sqrt(2 * adj_nu)))
    adj_Gauss.append((up - down) / dx_grid_long)
adj_Gauss = np.array(adj_Gauss)
adj_Gauss /= np.sum(adj_Gauss)

adj_z = (x_grid_long - delta_mu) / np.sqrt(adj_nu)
k3 = -np.sqrt(nu) / 3                      # gamma = -sqrt(nu)/3 from the third cumulant -nu^2/3
third_order = adj_Gauss * (np.power(adj_z, 3) - 3 * adj_z) * k3 / 6.0
corrected = adj_Gauss + third_order
corrected /= np.sum(corrected)
Theory = corrected - Gauss

# f_t = 0 reference (independent of K2, recomputed here for self-containedness)
NP_delta_nu = nu**2 / 9
NP_adj_nu = nu + NP_delta_nu
NP_delta_mu = -nu / 2
NP_adj_z = (x_grid_long - NP_delta_mu) / np.sqrt(NP_adj_nu)
NP_adj_Gauss = []
for x in x_grid_long:
    up = 0.5 * (1 + erf((x + dx_grid_long / 2 - NP_delta_mu) / np.sqrt(2 * NP_adj_nu)))
    down = 0.5 * (1 + erf((x - dx_grid_long / 2 - NP_delta_mu) / np.sqrt(2 * NP_adj_nu)))
    NP_adj_Gauss.append((up - down) / dx_grid_long)
NP_adj_Gauss = np.array(NP_adj_Gauss)
NP_adj_Gauss /= np.sum(NP_adj_Gauss)
NP_third_order = NP_adj_Gauss * (np.power(NP_adj_z, 3) - 3 * NP_adj_z) * k3 / 6.0
NP_corrected = NP_adj_Gauss + NP_third_order
NP_corrected /= np.sum(NP_corrected)
NP_Theory = NP_corrected - Gauss

np.save(os.path.join(OUT_DIR, f"theory{SUFFIX}.npy"), Theory)
np.save(os.path.join(OUT_DIR, f"NP_Theory{SUFFIX}.npy"), NP_Theory)

# SPDE histogram recovered from the saved residual -- no resampling needed
small_Gauss = Gauss.reshape(n_samples, factor_long).sum(axis=1)
statistics = numerical + small_Gauss

num_nu = np.sum(Gauss * np.power(x_grid_long, 2))
num_delta_mu = np.sum(statistics * x_grid)
num_delta_nu = np.sum(statistics * np.power(x_grid, 2)) - num_delta_mu**2 - num_nu

print()
print("--- theory vs SPDE numerics ---")
print(f"  delta_mu   theory {delta_mu:+.6e}   numerical {num_delta_mu:+.6e}")
print(f"  delta_nu   theory {delta_nu:+.6e}   numerical {num_delta_nu:+.6e}")

if K2_old is not None:
    old_K2_ff = np.sum(K2_old * np.outer(f, f)) * dt**2
    old_delta_nu = nu**2 / 9 + path_integral_J + double_path_integral_K1 + old_K2_ff
    old_spatial = -(alpha / 2) * (np.sum(J * G_f) * dt
                                  + np.sum((K1 + K2_old) * G_ff) * dt**2)
    old_delta_mu = -nu / 2 + old_spatial + path_var_excess
    print()
    print("--- effect of the correction ---")
    print(f"  K2.ff / nu^2   old {old_K2_ff/nu**2:+.6f}   new {double_path_integral_K2/nu**2:+.6f}")
    print(f"  delta_nu       old {old_delta_nu:+.6e}   new {delta_nu:+.6e}")
    print(f"  delta_mu       old {old_delta_mu:+.6e}   new {delta_mu:+.6e}")

# ----------------------------------------------------------------------------
# figures
# ----------------------------------------------------------------------------
ext = [t_grid[0], t_grid[-1], t_grid[0], t_grid[-1]]

plt.clf()
plt.imshow(K2 * np.outer(f, f), extent=ext, cmap='Greys', origin='lower',
           interpolation='None')
plt.xlabel('$t$', size=14)
plt.ylabel("$t'$", size=14, rotation=0)
plt.tight_layout()
plt.savefig(os.path.join(OUT_DIR, f"double_K2{SUFFIX}.pdf"))

plt.clf()
plt.imshow((K1 + K2) * G_ff, extent=ext, cmap='Greys', origin='lower',
           interpolation='None')
plt.xlabel('$t$', size=14)
plt.ylabel("$t'$", size=14, rotation=0)
plt.tight_layout()
plt.savefig(os.path.join(OUT_DIR, f"double_K_G_ff{SUFFIX}.pdf"))

plt.clf()
plt.scatter(x_grid, numerical / dx_grid, color='black', s=15)
plt.plot(x_grid_long, Theory / dx_grid_long, color='gray', linewidth=2)
plt.plot(x_grid_long, NP_Theory / dx_grid_long, color='gray', linestyle='--', linewidth=2)
plt.xlim(0.8 * x_grid[0], 0.8 * x_grid[-1])
plt.xlabel(r'$x$', size=14)
plt.ylabel(r'$\delta p$', size=14, rotation=0, labelpad=15)
plt.legend(['Numerical', 'Theory', r'$f_t = 0$ case'])
plt.tight_layout()
plt.savefig(os.path.join(OUT_DIR, f"numerical_path_impact{SUFFIX}.pdf"))

small_NP_Theory = NP_Theory.reshape(n_samples, factor_long).sum(axis=1)

plt.clf()
plt.scatter(x_grid, (numerical - small_NP_Theory) / dx_grid, color='black', s=15)
plt.plot(x_grid_long, (Theory - NP_Theory) / dx_grid_long, color='gray', linewidth=2)
plt.xlim(0.8 * x_grid[0], 0.8 * x_grid[-1])
plt.xlabel('$x$', size=14)
plt.ylabel(r'$\delta p-\widetilde{\delta p}$', size=14, rotation=0, labelpad=15)
plt.legend(['Numerical', 'Theory'])
plt.tight_layout()
plt.savefig(os.path.join(OUT_DIR, f"numerical_path_only{SUFFIX}.pdf"))

print()
print("written:",
      f"K2{SUFFIX}.npy, theory{SUFFIX}.npy, NP_Theory{SUFFIX}.npy,",
      f"double_K2{SUFFIX}.pdf, double_K_G_ff{SUFFIX}.pdf,",
      f"numerical_path_impact{SUFFIX}.pdf, numerical_path_only{SUFFIX}.pdf")
print(datetime.datetime.now())

